let h2 = React.createElement('h2',{},'This is header tag using of react js');
let p = React.createElement('p',{},'This is paragraph tag');
let root = ReactDOM.createRoot(document.getElementById('root'));
root.render([h2,p])
